package com.trigyn.configserverclient.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @Value("${user.name}")
    private String userName;
    
    @GetMapping("/getName")
    public String getUserName(){
        return userName;
    }
    
    @Value("${msg}")
    private String message;
    
    @GetMapping("/getMsg")
    public String getMessage(){
        return message;
    }
}
