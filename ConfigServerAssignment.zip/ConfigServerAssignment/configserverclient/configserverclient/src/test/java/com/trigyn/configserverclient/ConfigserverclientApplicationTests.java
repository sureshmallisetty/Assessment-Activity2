package com.trigyn.configserverclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigserverclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
